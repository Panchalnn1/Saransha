# my_app/utils.py

import os
import pandas as pd
import io
from scholarly import scholarly
from datetime import datetime

def load_and_filter_excel(file_path, sheet_name='Sheet1', columns=None, column_name=None, valid_names=None, cited_by_sort_order=None, year_range=None):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file {file_path} does not exist")

    try:
        df = pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        raise Exception(f"Failed to load the Excel file: {str(e)}")

    if columns:
        missing_columns = [col for col in columns if col not in df.columns]
        if missing_columns:
            print(f"Warning: The following columns are not in the sheet: {', '.join(missing_columns)}")
            columns = [col for col in columns if col in df.columns]
        df = df[columns]

    if column_name and valid_names:
        if column_name not in df.columns:
            raise ValueError(f"Column '{column_name}' does not exist in the DataFrame")
        df = df[df[column_name].isin(valid_names)]

    if cited_by_sort_order and 'Cited by' in df.columns:
        df['Cited by'] = pd.to_numeric(df['Cited by'], errors='coerce').fillna(0).astype(int)
        df = df.sort_values(by='Cited by', ascending=(cited_by_sort_order == 'asc'))
        

    if year_range and len(year_range) == 2:
        if 'Year' in df.columns:
            df = df[(df['Year'] >= year_range[0]) & (df['Year'] <= year_range[1])]
       
        

    return df

def get_publications_from_profile(profile_url):
    user_id = profile_url.split("user=")[1].split("&")[0]
    author = scholarly.search_author_id(user_id)
    scholarly.fill(author)
    main_author = author['name']
    current_date = datetime.now().strftime("%Y-%m-%d")

    publications_data = []

    for pub in author['publications']:
        scholarly.fill(pub)
        publication_details = {
            'Main Author': main_author,
            'Title': pub['bib']['title'],
            'conference': pub['bib'].get('conference', 'N/A'),
            'Journal': pub['bib'].get('journal', 'N/A'),
            'Year': pub['bib'].get('pub_year', 'N/A'),
            'Publication Type': pub['bib'].get('ENTRYTYPE', 'N/A'),
            'Cited by': pub.get('num_citations', 'N/A'),
            'Last Search Date': current_date
        }
        publications_data.append(publication_details)

    return publications_data

def process_profiles_from_excel(file_path, output_file):
    profiles_df = pd.read_excel(file_path)
    all_publications = []

    for profile_url in profiles_df['Profile URL']:
        try:
            publications = get_publications_from_profile(profile_url)
            all_publications.extend(publications)
        except Exception as e:
            print(f"Could not retrieve publications for {profile_url}: {e}")

    df = pd.DataFrame(all_publications)
    df.to_excel(output_file, index=False)
    print(f"All publication details saved to {output_file}")
