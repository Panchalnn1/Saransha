# my_app/views.py

from django.http import HttpResponse
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
import pandas as pd
import openpyxl
import io
from .utils import load_and_filter_excel, get_publications_from_profile, process_profiles_from_excel

def upload_page(request):
    excel_data = []
    publications_data = []

    if request.method == "POST" and request.FILES['excel_file']:
        excel_file = request.FILES['excel_file']
        
        fs = FileSystemStorage()
        filename = fs.save(excel_file.name, excel_file)
        file_path = fs.path(filename)

        output_file = fs.path("all_authors_publications.xlsx")
        process_profiles_from_excel(file_path, output_file)

        output_df = pd.read_excel(output_file)
        publications_data = output_df.to_dict(orient='records')

        workbook = openpyxl.load_workbook(file_path)
        worksheet = workbook.active
        for row in worksheet.iter_rows():
            row_data = [cell.value for cell in row]
            excel_data.append(row_data)

    return render(request, 'upload.html', {'excel_data': excel_data, 'publications_data': publications_data})

def generatesummary(request):
    authors = []
    result_df = pd.DataFrame()
    faculty_member = ""
    start_year = None
    end_year = None
    publication_type = ""
    sort_by = ""

    if request.method == 'POST':
        faculty_member = request.POST.get('facultySelect', "")
        start_year = request.POST.get('startYear')
        end_year = request.POST.get('endYear')
        publication_type = request.POST.get('publicationType', "")
        sort_by = request.POST.get('sortBy', "")

        try:
            start_year = int(start_year) if start_year else None
            end_year = int(end_year) if end_year else None
        except ValueError:
            start_year = None
            end_year = None

    fs = FileSystemStorage()
    output_file_path = fs.path("all_authors_publications.xlsx")

    if fs.exists(output_file_path):
        df = pd.read_excel(output_file_path)
        authors = df['Main Author'].unique().tolist()

        result_df = load_and_filter_excel(
            file_path=output_file_path,
            columns=['Main Author', 'Title','Journal','conference', "Year", "Cited by"],
            column_name='Main Author',
            valid_names=[faculty_member] if faculty_member != "All" else authors,
            year_range=[2010, 2024]
        )

        if "downloadSummary" in request.POST:
            buffer = io.BytesIO()
            with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                result_df.to_excel(writer, index=False, sheet_name='Summary')
            buffer.seek(0)

            response = HttpResponse(buffer, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            response['Content-Disposition'] = 'attachment; filename="filtered_summary.xlsx"'
            return response

    return render(request, "generatesummary.html", {
        'authors': authors,
        'result_df': result_df.to_dict(orient='records'),
    })

def home(request):
    return render(request,'index.html')

def settings(request):
    return render(request,'settings.html')

def help(request):
    return render(request,'help.html')

def login(request):
    return render(request,'login.html')
